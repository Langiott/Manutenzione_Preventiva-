%% RUL Stima con Modello di degradazione e aggiornamento della stima
% da "Update RUL Prediction as Data Arrives" 
% https://it.mathworks.com/help/predmaint/ug/update-rul-prediction-as-data-arrives.html

%% Pulizia
close all;
clear all;
clc;

%% Caricamento del dataset
load UpdateRULExampleData
% TrainingData, 24 tabelle con l'evoluzione run-to-failure di un indicatore
% TestData, 1 tabella con l'evoluzione run-to-failure di un indicatore
i = 1;
figure;
hold on
for i = 1:24
    plot(TrainingData{i, 1}.Time,TrainingData{i, 1}.Condition)
end
xlabel('Time [h]');
ylabel('Condition indicator');
legend

%% Addestramento di un modello di degradazione
mdl = exponentialDegradationModel('LifeTimeUnit',"hours"); % la variabile mdl è inizializzata a 0 nel workspace, ed è definita l'unità di misura del tempo (verificare i campi Theta, ThetaVariance, Beta, BetaVariance, Rho)
fit(mdl,TrainingData,"Time","Condition");
mdl.SlopeDetectionLevel = 0.1; % soglia a partire dalla quale è calcolata la stima della RUL (si sceglie empiricamente, e rappresenta il momento a partire dal quale inizia una degradazione)
threshold = 400; % soglia dopo la quale si considera ROTTO il componente
plot(0:1:250,400*ones(1,251));
hold off

%% Significato parametri modello
t = 0:1:249;
figure;
plot(t,0.01*exp(0.05*t));
hold on
plot(t,0.02*exp(0.05*t));
plot(t,0.01*exp(0.06*t));
legend('$\theta=0.01,\beta=0.05$','$\theta=0.02,\beta=0.05$','$\theta=0.01,\beta=0.06$','Interpreter','latex')
hold off

%% Stima online della RUL
% Usare TestData per calcolare la stima, e aggiornare ad ogni nuovo campione il modello
N = size(TestData,1); % dimensione array di test
EstRUL = hours(zeros(N,1)); % inizializzazione vettore stima della RUL, con associata l'unità di misura della variabile tempo, che sarà aggiornato di ora in ora
CI = hours(zeros(N,2)); % inizializzazione dell'intervallo di confidenza (limite superiore e inferiore), con associata l'unità di misura della variabile tempo, che sarà aggiornato di ora in ora
ModelParameters = zeros(N,3); % inizializzazione della struttura per conservare i parametri di modello (Theta, Beta, Rho) che saranno aggiornati di ora in ora
for t = 1:N
    CurrentDataSample = TestData(t,:); % restituisce una tabella 1x2 contenente il valore attuale del campione di test e l'istante attuale di valutazione
    update(mdl,CurrentDataSample) % aggiorna la stima a posteriori dei parametri del modello di degradazione, includendo l'ultimo campione disponibile "CurrentDataSample"
    ModelParameters(t,:) = [mdl.Theta mdl.Beta mdl.Rho]; % scrive i parametri di modello attuali
    % Calcola la RUL solo se i dati evidenziano un cambiamento
    % significativo della pendenza (i.e. avvio fase di degradazione)
    if ~isempty(mdl.SlopeDetectionInstant)
        [EstRUL(t),CI(t,:)] = predictRUL(mdl,CurrentDataSample,threshold);
    end
end

%% Plot parametri distribuzione stima
Time = hours(1:N)'; % crea il vettore dei tempi, con unità oraria
tStart = mdl.SlopeDetectionInstant; % salva il valore in cui la degradazione sale oltre la soglia
figure;
plot(Time, ModelParameters);
hold on
xline(tStart,'k--')
%plot([tStart, tStart],[-1,2],'k--')
legend({'\theta(t)','\beta(t)','\rho(t)','Slope detection instant'},'Location','best')
hold off

%% Plot stima RUL e intervalli di confidenza
figure
plot(Time,EstRUL,'b.-',Time,CI,'r',tStart,EstRUL(hours(tStart)),'g*')
title('Estimated RUL at Time t')
xlabel('t')
ylabel('Estimated RUL')
legend({'Predicted RUL','Confidence bound','Confidence bound','Slope detection instant'})

%% Plot test e verifica
figure
plot(TestData.Time,TestData.Condition)
xlabel('Time [h]');
ylabel('Condition indicator');
xline(161,'r--')
yline(400,'k--')
legend('Test Data','Failure Time','Thershold')