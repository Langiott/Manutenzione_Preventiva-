%% Pulizia desktop e workspace
close all;
clear all;
clc;

%% Parametri del motore
J_t = 0.01; % costante di inerzia [kg.m^2]
F_t = 0.1; % coefficiente di frizione [N.m.s]
K_e = 0.01; % flusso magnetico [N.m/A]
R_a = 1; % resistenza di armatura [ohm]
L_a = 0.5; % induttanza di armatura [H]

%% Creazione del modello in spazio di stato 1
A = [-R_a/L_a  -K_e/L_a
      K_e/J_t  -F_t/J_t];
B = [1/L_a
      0];
C = [0   1];
D = 0;
motor_ss = ss(A,B,C,D);

%% Osservatore dello stato
H=place(A',C',[-5;-4]).';
Ao = A-H*C;
Bo = [B,H];
Co = C;
Do = D;
observer_ss = ss(Ao,Bo,Co,Do);

%% Crezione del modello in spazio di stato 2 (che include il disturbo sulla coppia resistente, Cr(t))
Ad = A;
Bd = B;
Ed = [0;-1/J_t];
Be = [Bd Ed];
Cd = eye(2,2);
Dd = D;
motor_d_ss = ss(Ad,Be,Cd,Dd);

%% Osservatore dello stato 2
Hd=place(Ad',Cd',[-5;-4]).';
Aod = Ad-Hd*Cd;
Bod = [Bd,Hd];
Cod = Cd;
Dod = Dd;
observer_d_ss = ss(Aod,Bod,Cod,Dod);