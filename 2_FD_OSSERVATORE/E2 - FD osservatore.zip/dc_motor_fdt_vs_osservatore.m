% -----------------------------------------------------------------------%
% Lo script opera come segue:
%
% - carica i parametri di un motore elettrico a collettore in c.c.
% - genera la funzione di trasferimento del motore
% - genera il modello in spazio di stato del motore
% - genera un ingresso a gradino e uno sinusoidale di 10 secondi
% - simula il comportamento dei due modelli al variare dei due ingressi
% - crea un osservatore dello stato
% - confronta la stima dell'osservatore (stato e uscita) con quella del
% sistema reale
%
% Copyright: Alessandro Freddi - 24 Novembre 2021
% -----------------------------------------------------------------------%

%% Pulizia desktop e workspace
close all;
clear all;
clc;

%% Parametri del motore
J_t = 0.01; % costante di inerzia [kg.m^2]
F_t = 0.1; % coefficiente di frizione [N.m.s]
K_e = 0.01; % flusso magnetico [N.m/A]
R_a = 1; % resistenza di armatura [ohm]
L_a = 0.5; % induttanza di armatura [H]

%% Creazione del modello con funzione di trasferimento
s = tf('s'); % variabile di Laplace
motor_tf = K_e/((J_t*s+F_t)*(L_a*s+R_a)+K_e^2);

%% Creazione del modello in spazio di stato
A = [-R_a/L_a  -K_e/L_a
      K_e/J_t  -F_t/J_t];
B = [1/L_a
      0];
C = [0   1];
D = 0;
motor_ss = ss(A,B,C,D);

%% Creazione degli ingressi
t_sim = 0:.01:10; % tempo di simulazione
u_step = [zeros(1,101) 48*ones(1,900)]; % creazione di un ingresso a gradino di 10s con tempo di gradino pari a 1s
u_sin = 48*sin(t_sim); % creazione di un ingresso sinusoidale

%% Simulazione modello con funzione di trasferimento
figure(1);
lsim(motor_tf,u_step,t_sim);
title('Risposta a ciclo aperto con ingresso a gradino, fdt');
figure(2);
lsim(motor_tf,u_sin,t_sim);
title('Risposta a ciclo aperto con ingresso sinusoidale, fdt');

%% Simulazione modello in spazio di stato
figure(3);
lsim(motor_ss,u_step,t_sim);
title('Risposta a ciclo aperto con ingresso a gradino, ss');
figure(4);
lsim(motor_ss,u_sin,t_sim);
title('Risposta a ciclo aperto con ingresso sinusoidale, ss');

%% Osservatore dello stato
obsv(motor_ss); % verifica l'osservabilità del sistema
H=place(A',C',[-5;-4]).';
Ao = A-H*C;
Bo = [B,H];
Co = C;
Do = D;
observer_ss = ss(Ao,Bo,Co,Do);
[y_step,t_step,x_step]=lsim(motor_ss,u_step,t_sim);
[y_sin,t_sin,x_sin]=lsim(motor_ss,u_sin,t_sim);

%% Simulazione osservatore
u_step_o = [u_step;y_step'];
u_sin_o = [u_sin;y_sin'];
[y_step_o,t_step_o,x_step_o]=lsim(observer_ss,u_step_o,t_sim);
[y_sin_o,t_sin_o,x_sin_o]=lsim(observer_ss,u_sin_o,t_sim);

%% Confronto osservatore - sistema
x_step_e = x_step - x_step_o;
figure(5);
plot(t_step,x_step_e(:,1));
hold on
plot(t_step,x_step_e(:,2));
hold off
legend('Errore stima x1', 'Errore stima x2');
title('Errore di stima con ingresso a gradino');
x_sin_e = x_sin - x_sin_o;
figure(6);
plot(t_sin,x_sin_e(:,1));
hold on
plot(t_sin,x_sin_e(:,2));
hold off
legend('Errore stima x1', 'Errore stima x2');
title('Errore di stima con ingresso sinusoidale');
y_step_e = y_step - y_step_o;
figure(7);
plot(t_step,y_step_e(:,1));
title('Errore di uscita con ingresso a gradino');
y_sin_e = y_sin - y_sin_o;
figure(8);
plot(t_sin,y_sin_e(:,1));
title('Errore di uscita con ingresso sinusoidale');