% -----------------------------------------------------------------------%
% Lo script carica i parametri di un motore elettrico a collettore in c.c.
% per il successivo impiego in Simulink
%
% Copyright: Alessandro Freddi - 8 Settembre 2014
% -----------------------------------------------------------------------%

%% Pulizia desktop e workspace
close all;
clear all;
clc;

%% Parametri del motore
J_t = 0.01; % costante di inerzia [kg.m^2]
F_t = 0.1; % coefficiente di frizione [N.m.s]
K_e = 0.01; % flusso magnetico [N.m/A]
R_a = 1; % resistenza di armatura [ohm]
L_a = 0.5; % induttanza di armatura [H]

%% Parametri residui
K_m = K_e/(K_e^2+R_a*F_t);
T_m = J_t*R_a/(K_e^2+R_a*F_t);